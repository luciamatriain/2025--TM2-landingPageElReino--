var input_nombre= document.getElementById("nombre");
var input_pronombre= document.getElementById("pronombre");
var input_mail= document.getElementById("mail");