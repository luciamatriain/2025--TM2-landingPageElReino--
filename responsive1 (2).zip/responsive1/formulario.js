// Variables
var input_nombre = document.getElementById("nombre");
var input_pronombre = document.getElementById("pronombre");
var input_mail = document.getElementById("mail");
var input_submit = document.getElementById("boton-enviar");

var contenedorForm = document.querySelector(".contenedor-form");
var contenedorFeedback = document.querySelector(".feedback");


//Eventos
input_submit.addEventListener("click", enviarFormulario);

function enviarFormulario(event) {
  event.preventDefault();

  // Obtener valores
  var valor_nombre = input_nombre.value;
  var valor_pronombre = input_pronombre.value;
  var valor_mail = input_mail.value;

  // Contenido del feedback
  contenedorFeedback.innerHTML = `
    <h2 id="gracias3">¡Bienvenidx al Reino, ${valor_nombre}!</h2>
    <img src="img/hongo-feedback.png" alt="hongo feedback" class="img-feedback"> 
  `;

  // Intercambio de contenedores (capas)
  contenedorForm.style.display = "none";
  contenedorFeedback.style.zIndex = "2"; // encima del formulario
}